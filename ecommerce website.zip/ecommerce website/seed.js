const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Product = require('./models/Product');
const Order = require('./models/Order');

dotenv.config();

const sampleProducts = [
  {
    name: 'Wireless Bluetooth Earbuds with Bass Boost',
    description: 'Crisp sound, crystal-clear mic, 24-hour total playtime with compact charging case. Fast auto-pairing and sweat-proof for daily commute and workouts.',
    price: 799,
    originalPrice: 1999,
    category: 'Audio & Gadgets',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
    stock: 25,
    rating: 4.6,
    numReviews: 48,
    featured: true
  },
  {
    name: '10,000mAh Fast Charging Dual-Port Power Bank',
    description: 'Ultra-slim pocket power bank with 22.5W two-way fast charge. Multi-layer safety protection against over-voltage and overheating for all smartphones.',
    price: 899,
    originalPrice: 1599,
    category: 'Mobile Accessories',
    image: 'https://images.unsplash.com/photo-1609592424364-4b455b552fa7?w=800&auto=format&fit=crop&q=80',
    stock: 30,
    rating: 4.8,
    numReviews: 65,
    featured: true
  },
  {
    name: 'Smart Fitness Tracker Watch with Health Sensors',
    description: '1.47-inch AMOLED color touch display, all-day heart rate, SpO2 monitor, sleep tracking, and up to 14 days of long battery life.',
    price: 1499,
    originalPrice: 2999,
    category: 'Wearables',
    image: 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=800&auto=format&fit=crop&q=80',
    stock: 18,
    rating: 4.7,
    numReviews: 34,
    featured: true
  },
  {
    name: 'RGB Rainbow Backlit Desktop Keyboard',
    description: 'Durable tactile keys with anti-ghosting technology, adjustable RGB lighting modes, and spill-resistant design for office work and home entertainment.',
    price: 999,
    originalPrice: 1899,
    category: 'Computer Accessories',
    image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80',
    stock: 22,
    rating: 4.5,
    numReviews: 52,
    featured: false
  },
  {
    name: 'Mini Portable Waterproof Bluetooth Speaker',
    description: 'Compact 5W speaker delivering punchy bass and clear vocals. IPX6 water-resistant, built-in carry strap, and 8 hours of continuous music.',
    price: 649,
    originalPrice: 1299,
    category: 'Audio & Gadgets',
    image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80',
    stock: 40,
    rating: 4.6,
    numReviews: 29,
    featured: false
  },
  {
    name: 'Wireless Silent Optical Mouse (2.4GHz)',
    description: 'Ergonomic contoured shape with whisper-quiet click buttons. Plug-and-play USB nano receiver with 1600 DPI smooth optical tracking.',
    price: 299,
    originalPrice: 699,
    category: 'Computer Accessories',
    image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=800&auto=format&fit=crop&q=80',
    stock: 50,
    rating: 4.4,
    numReviews: 73,
    featured: false
  },
  {
    name: 'Stainless Steel Insulated Vacuum Flask 1000ml',
    description: 'Double-walled vacuum insulated flask keeping beverages icy cold for 24 hours or piping hot for 12 hours. Food-grade steel with leak-proof cap.',
    price: 399,
    originalPrice: 899,
    category: 'Home & Living',
    image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80',
    stock: 35,
    rating: 4.8,
    numReviews: 41,
    featured: true
  },
  {
    name: 'All-Weather Waterproof Laptop Backpack with USB Port',
    description: 'Spacious multi-compartment travel backpack fitting up to 15.6-inch laptops. Breathable mesh back support, padded straps, and external USB charge port.',
    price: 699,
    originalPrice: 1499,
    category: 'Bags & Travel',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
    stock: 20,
    rating: 4.7,
    numReviews: 88,
    featured: false
  },
  {
    name: 'Type-C to Type-C Braided Fast Cable (Pack of 2)',
    description: 'Tough nylon braided 60W fast-charging and data-sync cable. Bend-tested over 10,000 times for long-lasting durability.',
    price: 199,
    originalPrice: 499,
    category: 'Mobile Accessories',
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80',
    stock: 60,
    rating: 4.5,
    numReviews: 19,
    featured: false
  },
  {
    name: 'Eye-Care LED Study & Work Desk Lamp',
    description: 'Flicker-free natural LED light with 3 brightness modes. 360-degree flexible gooseneck arm and rechargeable battery with phone holder base.',
    price: 449,
    originalPrice: 899,
    category: 'Home & Living',
    image: 'https://images.unsplash.com/photo-1534349762230-e0cadf78f5da?w=800&auto=format&fit=crop&q=80',
    stock: 28,
    rating: 4.6,
    numReviews: 37,
    featured: false
  },
  {
    name: 'Lightweight Breathable Mesh Everyday Shoes',
    description: 'High-comfort cushioned EVA sole with breathable mesh upper. Perfect for daily walking, fitness, travel, and casual outings.',
    price: 899,
    originalPrice: 1999,
    category: 'Fashion & Footwear',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
    stock: 15,
    rating: 4.7,
    numReviews: 54,
    featured: true
  },
  {
    name: '1080p Smart WiFi Indoor Security Camera',
    description: '360-degree panoramic coverage with clear night vision, motion detection alerts, two-way audio talk, and micro-SD card recording for homes and shops.',
    price: 1299,
    originalPrice: 2499,
    category: 'Audio & Gadgets',
    image: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&auto=format&fit=crop&q=80',
    stock: 12,
    rating: 4.6,
    numReviews: 31,
    featured: false
  }
];

const seedData = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI;
    console.log(`Connecting to MongoDB...`);
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB.');

    // Clear old data
    await Order.deleteMany();
    await Product.deleteMany();
    console.log('Existing collections cleared.');

    // Insert sample products
    const createdProducts = await Product.insertMany(sampleProducts);
    console.log(`✅ Seeded ${createdProducts.length} BudgetMart store products.`);

    // Insert a sample demo order
    const sampleOrder = new Order({
      customerName: 'Pooja Sharma',
      orderItems: [
        {
          product: createdProducts[0]._id,
          name: createdProducts[0].name,
          qty: 1,
          price: createdProducts[0].price,
          image: createdProducts[0].image
        },
        {
          product: createdProducts[1]._id,
          name: createdProducts[1].name,
          qty: 1,
          price: createdProducts[1].price,
          image: createdProducts[1].image
        }
      ],
      shippingAddress: {
        fullName: 'Pooja Sharma',
        phone: '9876543210',
        address: 'Flat 302, Palm Heights, Main Market Road',
        city: 'Mumbai'
      },
      paymentMethod: 'Cash on Delivery (COD)',
      itemsPrice: createdProducts[0].price + createdProducts[1].price,
      shippingPrice: 0,
      discount: 100,
      totalPrice: (createdProducts[0].price + createdProducts[1].price) - 100,
      status: 'Processing'
    });

    await sampleOrder.save();
    console.log('✅ Sample demo order created.');

    console.log('\n=============================================');
    console.log('🎉 BUDGETMART SUPERSTORE DATABASE READY!');
    console.log('=============================================\n');

    process.exit(0);
  } catch (error) {
    console.error(`❌ Seeding error: ${error.message}`);
    process.exit(1);
  }
};

seedData();
