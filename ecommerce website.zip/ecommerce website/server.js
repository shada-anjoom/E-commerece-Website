const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const connectDB = require('./config/db');

// Route imports
const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');
const adminRoutes = require('./routes/adminRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

// Load environment variables
dotenv.config();

// Connect to MongoDB
connectDB();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// API Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    store: 'BudgetMart',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    dbConnected: require('mongoose').connection.readyState === 1
  });
});

// Mount API Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);

// Fallback for direct page visits without extension
app.get('/:page', (req, res, next) => {
  const allowedPages = [
    'index',
    'product',
    'cart',
    'checkout',
    'order-success',
    'orders',
    'login',
    'register',
    'admin'
  ];
  const requestedPage = req.params.page.replace('.html', '');
  if (allowedPages.includes(requestedPage)) {
    return res.sendFile(path.join(__dirname, 'public', `${requestedPage}.html`));
  }
  next();
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`
=====================================================
🛒 BudgetMart E-Commerce Server is running!
🌐 URL: http://localhost:${PORT}
⚙️  Environment: ${process.env.NODE_ENV || 'development'}
📦 API Health: http://localhost:${PORT}/api/health
=====================================================
  `);
});
