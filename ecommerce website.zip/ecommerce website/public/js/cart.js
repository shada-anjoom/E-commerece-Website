/**
 * BudgetMart - Shopping Cart
 */

document.addEventListener('DOMContentLoaded', () => {
  renderCart();
  setupPromoCode();
});

function renderCart() {
  const cart = getCart();
  const emptyState = document.getElementById('cartEmptyState');
  const cartContent = document.getElementById('cartContent');
  const itemsContainer = document.getElementById('cartItemsList');

  if (!cartContent || !emptyState || !itemsContainer) return;

  if (cart.length === 0) {
    cartContent.style.display = 'none';
    emptyState.style.display = 'block';
    return;
  }

  cartContent.style.display = 'grid';
  emptyState.style.display = 'none';

  itemsContainer.innerHTML = cart.map(item => `
    <tr class="cart-item-row" data-id="${item.product}">
      <td class="cart-item-cell">
        <div class="cart-item-product">
          <img src="${item.image}" alt="${item.name}" class="cart-thumb" />
          <div class="cart-item-info">
            <h4><a href="/product.html?id=${item.product}">${item.name}</a></h4>
            <span>${item.category || 'General'}</span>
            <br />
            <button type="button" class="cart-remove-btn" onclick="handleRemoveItem('${item.product}')">
              🗑️ Remove
            </button>
          </div>
        </div>
      </td>
      <td class="cart-item-cell" style="font-weight: 600;">
        ${formatPrice(item.price)}
      </td>
      <td class="cart-item-cell">
        <div class="quantity-picker" style="margin-bottom: 0;">
          <button type="button" class="qty-btn" onclick="handleChangeQty('${item.product}', ${item.qty - 1})">-</button>
          <input type="text" class="qty-input" value="${item.qty}" readonly />
          <button type="button" class="qty-btn" onclick="handleChangeQty('${item.product}', ${item.qty + 1})">+</button>
        </div>
      </td>
      <td class="cart-item-cell" style="font-weight: 800; color: var(--primary);">
        ${formatPrice(item.price * item.qty)}
      </td>
    </tr>
  `).join('');

  updateCartSummaryDisplay();
}

function handleChangeQty(productId, newQty) {
  updateCartQty(productId, newQty);
  renderCart();
}

function handleRemoveItem(productId) {
  removeFromCart(productId);
  renderCart();
}

function updateCartSummaryDisplay() {
  const totals = getCartTotals();

  document.getElementById('summaryItemsPrice').textContent = formatPrice(totals.itemsPrice);
  document.getElementById('summaryShipping').textContent = totals.shippingPrice === 0 ? 'FREE' : formatPrice(totals.shippingPrice);

  const discountRow = document.getElementById('summaryDiscountRow');
  const discountVal = document.getElementById('summaryDiscount');

  if (totals.discount > 0) {
    discountRow.style.display = 'flex';
    discountVal.textContent = `- ${formatPrice(totals.discount)}`;
  } else {
    discountRow.style.display = 'none';
  }

  document.getElementById('summaryTotal').textContent = formatPrice(totals.totalPrice);
}

function setupPromoCode() {
  const promoBtn = document.getElementById('btnApplyPromo');
  const promoInput = document.getElementById('promoCodeInput');
  const promoMessage = document.getElementById('promoMessage');

  if (!promoBtn || !promoInput) return;

  promoBtn.addEventListener('click', () => {
    const code = promoInput.value.trim().toUpperCase();

    if (code === 'BUDGET50') {
      localStorage.setItem('budgetmart_coupon', 'BUDGET50');
      showToast('Flat ₹50 discount applied!', 'success');
    } else if (code === 'SAVE10' || code === 'COLLEGE10') {
      localStorage.setItem('budgetmart_coupon', 'SAVE10');
      showToast('10% discount applied!', 'success');
    } else {
      showToast('Try coupon SAVE10 or BUDGET50', 'info');
      return;
    }

    if (promoMessage) {
      promoMessage.innerHTML = `<span style="color: var(--success); font-weight: 600;">✓ Coupon ${code} applied!</span>`;
    }

    updateCartSummaryDisplay();
  });
}
