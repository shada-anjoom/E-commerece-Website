/**
 * NovaTech E-Commerce - Home Page Catalog Logic
 */

let currentFilters = {
  keyword: '',
  category: 'All',
  sort: 'latest'
};

document.addEventListener('DOMContentLoaded', () => {
  // Read URL query params on load
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('search')) {
    currentFilters.keyword = urlParams.get('search');
  }
  if (urlParams.get('category')) {
    currentFilters.category = urlParams.get('category');
  }

  loadCategories();
  loadProducts();
  setupFilterListeners();
});

// Expose filter function for search bar in main.js
window.applyProductFilters = function (filters) {
  Object.assign(currentFilters, filters);
  loadProducts();
};

// Fetch and render category pills
async function loadCategories() {
  const container = document.getElementById('categoryPills');
  if (!container) return;

  try {
    const res = await apiRequest('/products/categories');
    if (res.success && res.categories) {
      let html = `
        <button type="button" class="category-pill ${currentFilters.category === 'All' ? 'active' : ''}" data-category="All">
          All Products
        </button>
      `;

      res.categories.forEach(cat => {
        const isActive = currentFilters.category.toLowerCase() === cat.toLowerCase();
        html += `
          <button type="button" class="category-pill ${isActive ? 'active' : ''}" data-category="${cat}">
            ${cat}
          </button>
        `;
      });

      container.innerHTML = html;

      // Attach click events
      container.querySelectorAll('.category-pill').forEach(btn => {
        btn.addEventListener('click', () => {
          container.querySelectorAll('.category-pill').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          currentFilters.category = btn.getAttribute('data-category');
          loadProducts();
        });
      });
    }
  } catch (error) {
    console.error('Failed to load categories:', error);
  }
}

// Fetch products based on active filters
async function loadProducts() {
  const grid = document.getElementById('productsGrid');
  const countSpan = document.getElementById('productCount');
  if (!grid) return;

  grid.innerHTML = `
    <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem;">
      <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid var(--gray-200); border-top-color: var(--primary); border-radius: 50%; animation: spin 1s infinite linear;"></div>
      <p style="margin-top: 1rem; color: var(--gray-500); font-weight: 500;">Loading fresh products...</p>
    </div>
    <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
  `;

  try {
    const queryParams = new URLSearchParams();
    if (currentFilters.keyword) queryParams.set('keyword', currentFilters.keyword);
    if (currentFilters.category && currentFilters.category !== 'All') queryParams.set('category', currentFilters.category);
    if (currentFilters.sort) queryParams.set('sort', currentFilters.sort);

    const res = await apiRequest(`/products?${queryParams.toString()}`);

    if (res.success && res.products) {
      if (countSpan) {
        countSpan.textContent = `Showing ${res.products.length} product${res.products.length === 1 ? '' : 's'}`;
      }

      if (res.products.length === 0) {
        grid.innerHTML = `
          <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem; background: var(--white); border-radius: var(--radius-lg); border: 1px dashed var(--gray-300);">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--dark); margin-bottom: 0.5rem;">No products found</h3>
            <p style="color: var(--gray-500); max-width: 400px; margin: 0 auto 1.5rem;">We couldn't find any items matching your selected criteria. Try searching for something else or reset your filters.</p>
            <button class="btn btn-primary" onclick="resetFilters()">Reset All Filters</button>
          </div>
        `;
        return;
      }

      grid.innerHTML = res.products.map(product => renderProductCard(product)).join('');

      // Attach "Add to Cart" button listeners
      grid.querySelectorAll('.btn-add-cart').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          const prodId = btn.getAttribute('data-id');
          const targetProduct = res.products.find(p => p._id === prodId);
          if (targetProduct) {
            addToCart(targetProduct, 1);
          }
        });
      });
    }
  } catch (error) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: var(--danger);">
        <p>⚠️ Unable to load products from server. Please verify MongoDB is running.</p>
      </div>
    `;
  }
}

// Generate single product card HTML
function renderProductCard(product) {
  const discountPercent = product.originalPrice && product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const discountBadge = discountPercent > 0
    ? `<span class="badge-discount">${discountPercent}% OFF</span>`
    : '';

  const featuredBadge = product.featured
    ? `<span class="badge-featured">⭐ Featured</span>`
    : '';

  const starsHtml = '★'.repeat(Math.floor(product.rating || 5)) + '☆'.repeat(5 - Math.floor(product.rating || 5));

  return `
    <div class="product-card">
      <div class="product-image-wrap">
        ${discountBadge}
        ${featuredBadge}
        <a href="/product.html?id=${product._id}">
          <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy" />
        </a>
      </div>
      <div class="product-content">
        <span class="product-cat">${product.category}</span>
        <h3 class="product-title">
          <a href="/product.html?id=${product._id}">${product.name}</a>
        </h3>
        <div class="product-rating">
          <span class="stars">${starsHtml}</span>
          <span class="rating-count">(${product.numReviews || 0})</span>
        </div>
        <div class="product-price-row">
          <span class="product-price">${formatPrice(product.price)}</span>
          ${product.originalPrice > product.price ? `<span class="product-original-price">${formatPrice(product.originalPrice)}</span>` : ''}
        </div>
        <div class="product-footer">
          <button type="button" class="btn-add-cart" data-id="${product._id}" ${product.stock <= 0 ? 'disabled' : ''}>
            ${product.stock > 0 ? '🛒 Add to Cart' : 'Out of Stock'}
          </button>
          <a href="/product.html?id=${product._id}" class="btn-quick-view" title="View Details">
            👁️
          </a>
        </div>
      </div>
    </div>
  `;
}

// Filter and Sort event handlers
function setupFilterListeners() {
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentFilters.sort = e.target.value;
      loadProducts();
    });
  }
}

function resetFilters() {
  currentFilters = {
    keyword: '',
    category: 'All',
    sort: 'latest'
  };
  const searchInput = document.getElementById('globalSearchInput');
  if (searchInput) searchInput.value = '';
  
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) sortSelect.value = 'latest';

  const container = document.getElementById('categoryPills');
  if (container) {
    container.querySelectorAll('.category-pill').forEach(b => b.classList.remove('active'));
    const allBtn = container.querySelector('[data-category="All"]');
    if (allBtn) allBtn.classList.add('active');
  }

  loadProducts();
}
