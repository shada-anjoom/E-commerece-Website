/**
 * BudgetMart - Simple API Client & Cart Helpers
 */

const API_BASE = '/api';

// Format Price in ₹ INR
function formatPrice(amount) {
  const num = Number(amount) || 0;
  return '₹' + num.toLocaleString('en-IN');
}

// Simple Request Wrapper
async function apiRequest(endpoint, method = 'GET', data = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  if (data && ['POST', 'PUT', 'PATCH'].includes(method.toUpperCase())) {
    options.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, options);
    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'API request failed');
    }

    return result;
  } catch (error) {
    console.error(`API Error [${method} ${endpoint}]:`, error);
    throw error;
  }
}

// Shopping Cart (Stored in localStorage)
function getCart() {
  const cart = localStorage.getItem('budgetmart_cart');
  try {
    return cart ? JSON.parse(cart) : [];
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem('budgetmart_cart', JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(product, qty = 1) {
  const cart = getCart();
  const existing = cart.find(item => item.product === product._id);

  if (existing) {
    existing.qty += qty;
    showToast(`Updated quantity in cart!`, 'success');
  } else {
    cart.push({
      product: product._id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      qty: qty
    });
    showToast(`Added "${product.name}" to your cart!`, 'success');
  }

  saveCart(cart);
}

function updateCartQty(productId, qty) {
  const cart = getCart();
  const item = cart.find(i => i.product === productId);
  if (item) {
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }
    item.qty = qty;
    saveCart(cart);
  }
}

function removeFromCart(productId) {
  let cart = getCart();
  cart = cart.filter(i => i.product !== productId);
  saveCart(cart);
  showToast('Item removed from cart', 'info');
}

function clearCart() {
  localStorage.removeItem('budgetmart_cart');
  localStorage.removeItem('budgetmart_coupon');
  updateCartBadge();
}

function getCartCount() {
  const cart = getCart();
  return cart.reduce((total, item) => total + item.qty, 0);
}

function getCartTotals() {
  const cart = getCart();
  const itemsPrice = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const shippingPrice = itemsPrice >= 499 || itemsPrice === 0 ? 0 : 49;
  
  // Coupon
  const coupon = localStorage.getItem('budgetmart_coupon');
  let discount = 0;
  if (coupon === 'BUDGET50') {
    discount = Math.min(50, itemsPrice);
  } else if (coupon === 'SAVE10' || coupon === 'COLLEGE10') {
    discount = Math.round(itemsPrice * 0.10);
  }

  const totalPrice = Math.max(0, itemsPrice + shippingPrice - discount);

  return {
    itemsPrice,
    shippingPrice,
    discount,
    totalPrice
  };
}

function updateCartBadge() {
  const badge = document.getElementById('cartBadge');
  if (badge) {
    const count = getCartCount();
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline-block' : 'none';
  }
}

// Simple Toast Notification
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${type === 'success' ? '✅' : 'ℹ️'}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

document.addEventListener('DOMContentLoaded', updateCartBadge);
