/**
 * BudgetMart - Main Navigation
 */

document.addEventListener('DOMContentLoaded', () => {
  setupSearchForm();
  updateCartBadge();
});

function setupSearchForm() {
  const searchForm = document.getElementById('globalSearchForm');
  const searchInput = document.getElementById('globalSearchInput');

  if (searchForm && searchInput) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentSearch = urlParams.get('search');
    if (currentSearch) {
      searchInput.value = currentSearch;
    }

    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const query = searchInput.value.trim();
      const isHome = window.location.pathname === '/' || window.location.pathname.endsWith('index.html');

      if (isHome && typeof window.applyProductFilters === 'function') {
        window.applyProductFilters({ keyword: query });
      } else {
        window.location.href = query ? `/index.html?search=${encodeURIComponent(query)}` : '/index.html';
      }
    });
  }
}
