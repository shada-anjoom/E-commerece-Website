/**
 * NovaTech E-Commerce - Product Detail Logic
 */

let currentProduct = null;
let selectedQuantity = 1;

document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  if (!productId) {
    window.location.href = '/index.html';
    return;
  }

  loadProductDetails(productId);
});

async function loadProductDetails(id) {
  const detailContainer = document.getElementById('productDetailContainer');
  if (!detailContainer) return;

  try {
    const res = await apiRequest(`/products/${id}`);
    if (res.success && res.product) {
      currentProduct = res.product;
      renderProductDetails(currentProduct);
      loadRelatedProducts(currentProduct.category, currentProduct._id);
    } else {
      detailContainer.innerHTML = `<p class="text-danger">Product not found.</p>`;
    }
  } catch (error) {
    detailContainer.innerHTML = `
      <div style="text-align: center; padding: 4rem 1rem;">
        <h2>Product Not Found</h2>
        <p style="color: var(--gray-500); margin: 1rem 0;">The item you are looking for does not exist or has been removed.</p>
        <a href="/index.html" class="btn btn-primary">Browse All Products</a>
      </div>
    `;
  }
}

function renderProductDetails(product) {
  // Update document title
  document.title = `${product.name} - NovaTech E-Commerce`;

  // Breadcrumbs
  const breadcrumbCat = document.getElementById('breadcrumbCategory');
  const breadcrumbTitle = document.getElementById('breadcrumbTitle');
  if (breadcrumbCat) {
    breadcrumbCat.textContent = product.category;
    breadcrumbCat.href = `/index.html?category=${encodeURIComponent(product.category)}`;
  }
  if (breadcrumbTitle) {
    breadcrumbTitle.textContent = product.name;
  }

  // Image
  const mainImg = document.getElementById('productMainImage');
  if (mainImg) {
    mainImg.src = product.image;
    mainImg.alt = product.name;
  }

  // Content
  document.getElementById('productCategory').textContent = product.category;
  document.getElementById('productTitle').textContent = product.name;

  const starsHtml = '★'.repeat(Math.floor(product.rating || 5)) + '☆'.repeat(5 - Math.floor(product.rating || 5));
  document.getElementById('productStars').innerHTML = starsHtml;
  document.getElementById('productReviews').textContent = `(${product.numReviews || 0} customer reviews)`;

  // Pricing
  document.getElementById('productPrice').textContent = formatPrice(product.price);
  const originalPriceEl = document.getElementById('productOriginalPrice');
  if (originalPriceEl) {
    if (product.originalPrice > product.price) {
      originalPriceEl.textContent = formatPrice(product.originalPrice);
      originalPriceEl.style.display = 'inline';
    } else {
      originalPriceEl.style.display = 'none';
    }
  }

  // Stock status badge
  const stockBadge = document.getElementById('productStockBadge');
  if (stockBadge) {
    if (product.stock > 0) {
      stockBadge.className = 'stock-badge stock-in';
      stockBadge.innerHTML = `✓ In Stock (${product.stock} units available)`;
    } else {
      stockBadge.className = 'stock-badge stock-out';
      stockBadge.innerHTML = `✕ Out of Stock`;
    }
  }

  // Description
  document.getElementById('productDescription').textContent = product.description;

  // Quantity and buttons setup
  setupQuantityPicker(product.stock);
  setupActionButtons();
}

function setupQuantityPicker(maxStock) {
  const qtyInput = document.getElementById('qtyInput');
  const btnMinus = document.getElementById('btnQtyMinus');
  const btnPlus = document.getElementById('btnQtyPlus');

  if (!qtyInput || !btnMinus || !btnPlus) return;

  btnMinus.addEventListener('click', () => {
    if (selectedQuantity > 1) {
      selectedQuantity--;
      qtyInput.value = selectedQuantity;
    }
  });

  btnPlus.addEventListener('click', () => {
    if (selectedQuantity < maxStock) {
      selectedQuantity++;
      qtyInput.value = selectedQuantity;
    } else {
      showToast(`Only ${maxStock} items available in stock`, 'info');
    }
  });

  qtyInput.addEventListener('change', () => {
    let val = parseInt(qtyInput.value, 10);
    if (isNaN(val) || val < 1) val = 1;
    if (val > maxStock) val = maxStock;
    selectedQuantity = val;
    qtyInput.value = val;
  });
}

function setupActionButtons() {
  const btnAddToCart = document.getElementById('btnAddToCart');
  const btnBuyNow = document.getElementById('btnBuyNow');

  if (btnAddToCart) {
    btnAddToCart.addEventListener('click', () => {
      if (currentProduct && currentProduct.stock > 0) {
        addToCart(currentProduct, selectedQuantity);
      }
    });
  }

  if (btnBuyNow) {
    btnBuyNow.addEventListener('click', () => {
      if (currentProduct && currentProduct.stock > 0) {
        addToCart(currentProduct, selectedQuantity);
        window.location.href = '/checkout.html';
      }
    });
  }
}

// Load related products from the same category
async function loadRelatedProducts(category, currentId) {
  const container = document.getElementById('relatedProductsGrid');
  if (!container) return;

  try {
    const res = await apiRequest(`/products?category=${encodeURIComponent(category)}`);
    if (res.success && res.products) {
      const related = res.products.filter(p => p._id !== currentId).slice(0, 4);

      if (related.length === 0) {
        container.closest('.related-section').style.display = 'none';
        return;
      }

      container.innerHTML = related.map(product => `
        <div class="product-card">
          <div class="product-image-wrap">
            <a href="/product.html?id=${product._id}">
              <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy" />
            </a>
          </div>
          <div class="product-content">
            <span class="product-cat">${product.category}</span>
            <h4 class="product-title">
              <a href="/product.html?id=${product._id}">${product.name}</a>
            </h4>
            <div class="product-price-row">
              <span class="product-price">${formatPrice(product.price)}</span>
            </div>
            <a href="/product.html?id=${product._id}" class="btn btn-secondary btn-sm btn-block">View Item</a>
          </div>
        </div>
      `).join('');
    }
  } catch (e) {
    console.error('Failed to load related products', e);
  }
}
