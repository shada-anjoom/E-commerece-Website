/**
 * BudgetMart - Direct Guest Checkout (No Login Required)
 */

document.addEventListener('DOMContentLoaded', () => {
  const cart = getCart();

  if (cart.length === 0) {
    showToast('Your cart is empty!', 'info');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 1200);
    return;
  }

  renderCheckoutSummary();
  setupCheckoutForm();
});

function renderCheckoutSummary() {
  const cart = getCart();
  const totals = getCartTotals();
  const itemsContainer = document.getElementById('checkoutItemsList');

  if (itemsContainer) {
    itemsContainer.innerHTML = cart.map(item => `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; font-size: 0.9rem;">
        <div style="display: flex; align-items: center; gap: 0.65rem;">
          <img src="${item.image}" alt="${item.name}" style="width: 40px; height: 40px; border-radius: 6px; object-fit: cover;" />
          <div>
            <div style="font-weight: 600; max-width: 190px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.name}</div>
            <div style="color: #64748b; font-size: 0.8rem;">Qty: ${item.qty} × ${formatPrice(item.price)}</div>
          </div>
        </div>
        <div style="font-weight: 700;">${formatPrice(item.price * item.qty)}</div>
      </div>
    `).join('');
  }

  document.getElementById('checkoutItemsPrice').textContent = formatPrice(totals.itemsPrice);
  document.getElementById('checkoutShipping').textContent = totals.shippingPrice === 0 ? 'FREE' : formatPrice(totals.shippingPrice);

  const discountRow = document.getElementById('checkoutDiscountRow');
  const discountVal = document.getElementById('checkoutDiscount');
  if (totals.discount > 0) {
    discountRow.style.display = 'flex';
    discountVal.textContent = `- ${formatPrice(totals.discount)}`;
  } else {
    discountRow.style.display = 'none';
  }

  document.getElementById('checkoutTotalPrice').textContent = formatPrice(totals.totalPrice);
}

function setupCheckoutForm() {
  const form = document.getElementById('checkoutForm');
  const placeOrderBtn = document.getElementById('btnPlaceOrder');

  if (!form || !placeOrderBtn) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Simple fields - no strict regex, optional values accepted
    const fullName = (document.getElementById('shippingFullName').value || '').trim() || 'Valued Customer';
    const phone = (document.getElementById('shippingPhone').value || '').trim() || 'Not Provided';
    const address = (document.getElementById('shippingAddress').value || '').trim() || 'Campus Delivery';
    const city = (document.getElementById('shippingCity').value || '').trim() || 'Local Area';

    const selectedPayment = document.querySelector('input[name="paymentMethod"]:checked');
    const paymentMethod = selectedPayment ? selectedPayment.value : 'Cash on Delivery (COD)';

    const cart = getCart();
    const totals = getCartTotals();

    const orderPayload = {
      customerName: fullName,
      orderItems: cart.map(i => ({
        product: i.product,
        name: i.name,
        qty: i.qty,
        price: i.price,
        image: i.image
      })),
      shippingAddress: {
        fullName,
        phone,
        address,
        city
      },
      paymentMethod,
      itemsPrice: totals.itemsPrice,
      shippingPrice: totals.shippingPrice,
      discount: totals.discount,
      totalPrice: totals.totalPrice
    };

    try {
      placeOrderBtn.disabled = true;
      placeOrderBtn.innerHTML = `<span>⏳ Placing Your Order...</span>`;

      const response = await apiRequest('/orders', 'POST', orderPayload);

      if (response.success && response.order) {
        clearCart();
        showToast('🎉 Order Placed Successfully!', 'success');
        setTimeout(() => {
          window.location.href = `/order-success.html?id=${response.order._id}`;
        }, 800);
      }
    } catch (error) {
      showToast(error.message || 'Could not place order', 'error');
      placeOrderBtn.disabled = false;
      placeOrderBtn.innerHTML = `Confirm Order`;
    }
  });
}
