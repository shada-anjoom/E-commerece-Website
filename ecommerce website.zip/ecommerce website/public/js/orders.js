/**
 * BudgetMart - Orders History & Tracking
 */

document.addEventListener('DOMContentLoaded', () => {
  loadOrders();
});

async function loadOrders() {
  const container = document.getElementById('ordersListContainer');
  const countSpan = document.getElementById('ordersCount');
  if (!container) return;

  try {
    const res = await apiRequest('/orders');

    if (res.success && res.orders) {
      if (countSpan) {
        countSpan.textContent = `${res.orders.length} order(s) placed`;
      }

      if (res.orders.length === 0) {
        container.innerHTML = `
          <div style="text-align: center; padding: 4rem 1rem; background: var(--white); border-radius: var(--radius-lg); border: 1px dashed var(--gray-300);">
            <div style="font-size: 3rem; margin-bottom: 1rem;">📦</div>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--dark); margin-bottom: 0.5rem;">No orders yet</h3>
            <p style="color: var(--gray-500); max-width: 400px; margin: 0 auto 1.5rem;">Browse BudgetMart and place your first order!</p>
            <a href="/index.html" class="btn btn-primary">Start Shopping</a>
          </div>
        `;
        return;
      }

      container.innerHTML = res.orders.map(order => renderOrderCard(order)).join('');
    }
  } catch (error) {
    container.innerHTML = `
      <div style="text-align: center; padding: 3rem; color: var(--danger);">
        <p>⚠️ Unable to load orders: ${error.message}</p>
      </div>
    `;
  }
}

function renderOrderCard(order) {
  const dateFormatted = new Date(order.createdAt).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  const customerName = order.customerName || (order.shippingAddress && order.shippingAddress.fullName) || 'Customer';

  return `
    <div style="background: var(--white); border: 1px solid var(--gray-200); border-radius: var(--radius-lg); margin-bottom: 1.5rem; overflow: hidden; box-shadow: var(--shadow-sm);">
      <div style="background: var(--gray-50); border-bottom: 1px solid var(--gray-200); padding: 1.25rem 1.5rem; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem;">
        <div>
          <div style="font-size: 0.8rem; color: var(--gray-500); text-transform: uppercase; font-weight: 700;">Customer</div>
          <div style="font-size: 0.95rem; font-weight: 700; color: var(--dark);">${customerName}</div>
        </div>
        <div>
          <div style="font-size: 0.8rem; color: var(--gray-500); text-transform: uppercase; font-weight: 700;">Order Date</div>
          <div style="font-size: 0.9rem; font-weight: 600;">${dateFormatted}</div>
        </div>
        <div>
          <div style="font-size: 0.8rem; color: var(--gray-500); text-transform: uppercase; font-weight: 700;">Total Amount</div>
          <div style="font-size: 1.05rem; font-weight: 800; color: var(--primary);">${formatPrice(order.totalPrice)}</div>
        </div>
        <div>
          <span class="status-badge status-${order.status}">${order.status}</span>
        </div>
      </div>

      <div style="padding: 1.5rem;">
        <div style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1.25rem;">
          ${order.orderItems.map(item => `
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; border-bottom: 1px solid var(--gray-100); padding-bottom: 0.6rem;">
              <div style="display: flex; align-items: center; gap: 0.85rem;">
                <img src="${item.image}" alt="${item.name}" style="width: 44px; height: 44px; border-radius: 4px; object-fit: cover;" />
                <div>
                  <h4 style="font-size: 0.92rem; font-weight: 700; margin-bottom: 0.1rem;">${item.name}</h4>
                  <span style="font-size: 0.8rem; color: var(--gray-500);">Qty: ${item.qty} × ${formatPrice(item.price)}</span>
                </div>
              </div>
              <div style="font-weight: 700; font-size: 0.95rem;">
                ${formatPrice(item.price * item.qty)}
              </div>
            </div>
          `).join('')}
        </div>

        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem; font-size: 0.85rem; color: var(--gray-600); border-top: 1px solid var(--gray-200); padding-top: 1rem;">
          <div>
            <strong>Delivery to:</strong> ${order.shippingAddress ? `${order.shippingAddress.address}, ${order.shippingAddress.city}` : 'Local'} 
            ${order.shippingAddress && order.shippingAddress.phone ? `(Phone: ${order.shippingAddress.phone})` : ''}
          </div>
          <div>
            <a href="/order-success.html?id=${order._id}" class="btn btn-secondary btn-sm">📄 View Bill / Receipt</a>
          </div>
        </div>
      </div>
    </div>
  `;
}
