/**
 * BudgetMart - Simple Admin Controller
 */

let allProductsCache = [];
let editingProductId = null;

document.addEventListener('DOMContentLoaded', () => {
  setupAdminTabs();
  loadAdminStats();
  loadAdminProducts();
  loadAdminOrders();
  setupProductModal();
});

function setupAdminTabs() {
  const navItems = document.querySelectorAll('.admin-nav-item[data-tab]');
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const targetTab = item.getAttribute('data-tab');

      navItems.forEach(i => i.classList.remove('active'));
      item.classList.add('active');

      document.querySelectorAll('.admin-panel').forEach(panel => {
        panel.classList.remove('active');
      });

      const activePanel = document.getElementById(`tab-${targetTab}`);
      if (activePanel) {
        activePanel.classList.add('active');
      }

      if (targetTab === 'stats') loadAdminStats();
      if (targetTab === 'products') loadAdminProducts();
      if (targetTab === 'orders') loadAdminOrders();
    });
  });
}

// 1. Dashboard KPI Stats
async function loadAdminStats() {
  try {
    const res = await apiRequest('/admin/stats');
    if (res.success && res.stats) {
      const { totalRevenue, totalOrders, totalProducts, lowStockProducts } = res.stats;

      document.getElementById('statTotalRevenue').textContent = formatPrice(totalRevenue);
      document.getElementById('statTotalOrders').textContent = totalOrders;
      document.getElementById('statTotalProducts').textContent = totalProducts;
      document.getElementById('statTotalUsers').textContent = totalOrders;

      const lowStockTbody = document.getElementById('lowStockTableBody');
      if (lowStockTbody) {
        if (!lowStockProducts || lowStockProducts.length === 0) {
          lowStockTbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--success); font-weight: 600;">✓ All items in stock</td></tr>`;
        } else {
          lowStockTbody.innerHTML = lowStockProducts.map(p => `
            <tr>
              <td>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                  <img src="${p.image}" class="table-thumb" alt="${p.name}" />
                  <strong>${p.name}</strong>
                </div>
              </td>
              <td>${p.category}</td>
              <td>${formatPrice(p.price)}</td>
              <td><span style="color: var(--danger); font-weight: 700;">⚠️ ${p.stock} left</span></td>
            </tr>
          `).join('');
        }
      }
    }
  } catch (error) {
    console.error('Failed to load admin stats:', error);
  }
}

// 2. Product Management
async function loadAdminProducts() {
  const tbody = document.getElementById('adminProductsTableBody');
  if (!tbody) return;

  try {
    const res = await apiRequest('/products');
    if (res.success && res.products) {
      allProductsCache = res.products;

      if (res.products.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 2rem;">No products found.</td></tr>`;
        return;
      }

      tbody.innerHTML = res.products.map(p => `
        <tr data-id="${p._id}">
          <td>
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <img src="${p.image}" alt="${p.name}" class="table-thumb" />
              <strong>${p.name}</strong>
            </div>
          </td>
          <td><span style="background: #f1f5f9; padding: 3px 8px; border-radius: 4px; font-size: 0.82rem;">${p.category}</span></td>
          <td style="font-weight: 700;">${formatPrice(p.price)}</td>
          <td>
            <span style="font-weight: 700; ${p.stock <= 5 ? 'color: var(--danger);' : 'color: var(--success);'}">
              ${p.stock} units
            </span>
          </td>
          <td>★ ${p.rating || 4.5}</td>
          <td>
            <div class="action-btns">
              <button type="button" class="btn btn-secondary btn-sm" onclick="openEditProductModal('${p._id}')">✏️ Edit</button>
              <button type="button" class="btn btn-danger btn-sm" onclick="handleDeleteProduct('${p._id}', '${escapeQuotes(p.name)}')">🗑️ Delete</button>
            </div>
          </td>
        </tr>
      `).join('');
    }
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--danger);">Failed to load products: ${error.message}</td></tr>`;
  }
}

function escapeQuotes(str) {
  return (str || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}

function setupProductModal() {
  const modal = document.getElementById('productModal');
  const btnOpenAdd = document.getElementById('btnOpenAddProduct');
  const btnClose = document.getElementById('btnCloseProductModal');
  const btnCancel = document.getElementById('btnCancelProductModal');
  const form = document.getElementById('productForm');

  if (!modal || !form) return;

  const closeModal = () => {
    modal.classList.remove('open');
    editingProductId = null;
    form.reset();
  };

  if (btnOpenAdd) {
    btnOpenAdd.addEventListener('click', () => {
      editingProductId = null;
      document.getElementById('modalProductTitle').textContent = 'Add New Product';
      form.reset();
      modal.classList.add('open');
    });
  }

  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const productData = {
      name: document.getElementById('formProdName').value.trim(),
      category: document.getElementById('formProdCategory').value.trim(),
      price: Number(document.getElementById('formProdPrice').value),
      originalPrice: Number(document.getElementById('formProdOriginalPrice').value || 0),
      stock: Number(document.getElementById('formProdStock').value || 10),
      image: document.getElementById('formProdImage').value.trim(),
      description: document.getElementById('formProdDescription').value.trim()
    };

    try {
      if (editingProductId) {
        await apiRequest(`/products/${editingProductId}`, 'PUT', productData);
        showToast('Product updated successfully!', 'success');
      } else {
        await apiRequest('/products', 'POST', productData);
        showToast('Product added to catalog!', 'success');
      }

      closeModal();
      loadAdminProducts();
      loadAdminStats();
    } catch (error) {
      showToast(error.message || 'Failed to save product', 'error');
    }
  });
}

function openEditProductModal(id) {
  const product = allProductsCache.find(p => p._id === id);
  if (!product) return;

  editingProductId = id;
  document.getElementById('modalProductTitle').textContent = 'Edit Product';

  document.getElementById('formProdName').value = product.name;
  document.getElementById('formProdCategory').value = product.category;
  document.getElementById('formProdPrice').value = product.price;
  document.getElementById('formProdOriginalPrice').value = product.originalPrice || '';
  document.getElementById('formProdStock').value = product.stock;
  document.getElementById('formProdImage').value = product.image;
  document.getElementById('formProdDescription').value = product.description;

  const modal = document.getElementById('productModal');
  if (modal) modal.classList.add('open');
}

async function handleDeleteProduct(id, name) {
  if (!confirm(`Delete "${name}"?`)) return;

  try {
    await apiRequest(`/products/${id}`, 'DELETE');
    showToast('Product deleted!', 'info');
    loadAdminProducts();
    loadAdminStats();
  } catch (error) {
    showToast(error.message || 'Failed to delete product', 'error');
  }
}

// 3. Orders Management
async function loadAdminOrders() {
  const tbody = document.getElementById('adminOrdersTableBody');
  if (!tbody) return;

  try {
    const res = await apiRequest('/admin/orders');
    if (res.success && res.orders) {
      if (res.orders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 2rem;">No orders placed yet.</td></tr>`;
        return;
      }

      tbody.innerHTML = res.orders.map(order => {
        const orderDate = new Date(order.createdAt).toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short'
        });

        const customerName = order.customerName || (order.shippingAddress && order.shippingAddress.fullName) || 'Customer';

        return `
          <tr data-order-id="${order._id}">
            <td><code style="font-weight: 700;">#${order._id.substring(order._id.length - 6)}</code></td>
            <td><strong>${customerName}</strong></td>
            <td>${orderDate}</td>
            <td>${order.orderItems.length} item(s)</td>
            <td style="font-weight: 700; color: var(--primary);">${formatPrice(order.totalPrice)}</td>
            <td>
              <select class="form-control" style="padding: 0.25rem 0.5rem; font-size: 0.85rem;" onchange="handleUpdateOrderStatus('${order._id}', this.value)">
                <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                <option value="Processing" ${order.status === 'Processing' ? 'selected' : ''}>Processing</option>
                <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
                <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                <option value="Cancelled" ${order.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
              </select>
            </td>
            <td>
              <a href="/order-success.html?id=${order._id}" target="_blank" class="btn btn-secondary btn-sm">👁️ Bill</a>
            </td>
          </tr>
        `;
      }).join('');
    }
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--danger);">Failed to load orders: ${error.message}</td></tr>`;
  }
}

async function handleUpdateOrderStatus(orderId, newStatus) {
  try {
    await apiRequest(`/orders/${orderId}/status`, 'PUT', { status: newStatus });
    showToast(`Order updated to "${newStatus}"`, 'success');
    loadAdminStats();
  } catch (error) {
    showToast(error.message || 'Failed to update order status', 'error');
  }
}
