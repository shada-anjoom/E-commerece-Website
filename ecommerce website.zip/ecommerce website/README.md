# 🛒 BudgetMart - Online Superstore

A modern, fast, and responsive e-commerce web application built with **Node.js, Express.js, MongoDB (Mongoose), HTML5, CSS3, and JavaScript**.

---

## 🌟 Store Features

- **Universal Online Store**: Clean, modern shopping experience for everyone with zero barriers.
- **Direct Guest Shopping**: Customers can browse, add to cart, and checkout immediately without mandatory sign-in or account creation.
- **Simplified Checkout**: Direct doorstep delivery form with no strict email or mobile format blockers.
- **Product Search & Categories**: Live search by product title/description, category filtering, and sorting (Price: Low to High, Price: High to Low, Rating).
- **Interactive Shopping Cart**: Quantity adjustments (`+` / `-`), item removal, live total calculation with Free Shipping on orders over ₹499.
- **Discount Coupons**: Use coupon code **`SAVE10`** for 10% off or **`BUDGET50`** for ₹50 flat discount.
- **Payment Options**: Cash on Delivery (COD), Demo UPI, and Demo Card simulation.
- **Printable Invoices & Tracking**: Immediate printable tax receipt with order status tracking.
- **Direct Store Admin Panel**: Accessible via **⚙️ Admin Panel** in the navigation bar to monitor revenue, total orders, add/edit/delete products, and update customer order delivery statuses.

---

## 📁 Project Structure

```text
ecommerce website/
├── .env                  # MongoDB connection string & PORT
├── package.json          # Node scripts and dependencies
├── server.js             # Express server entry point
├── seed.js               # Database seeder (12 catalog items & demo order)
├── config/
│   └── db.js             # MongoDB connection logic
├── models/
│   ├── Product.js        # Product catalog schema
│   └── Order.js          # Customer order schema
├── routes/
│   ├── productRoutes.js  # Product queries & Admin CRUD
│   ├── orderRoutes.js    # Order placement & status updates
│   └── adminRoutes.js    # Dashboard analytics
└── public/
    ├── index.html        # Storefront Home Page
    ├── product.html      # Product Details & Recommendations
    ├── cart.html         # Shopping Cart & Coupons
    ├── checkout.html     # Instant Doorstep Checkout
    ├── order-success.html# Confirmation & Printable Invoice
    ├── orders.html       # Customer Orders Tracking
    ├── admin.html        # Store Admin Panel
    ├── css/
    │   ├── style.css     # Responsive theme styles
    │   └── admin.css     # Admin dashboard layout
    └── js/
        ├── api.js        # API client & cart storage
        ├── main.js       # Search bar handler
        ├── home.js       # Catalog & category filter
        ├── product.js    # Single product details & quantity
        ├── cart.js       # Cart calculation & coupons
        ├── checkout.js   # Fast order placement
        ├── orders.js     # Orders list renderer
        └── admin.js      # Admin CRUD & status updater
```

---

## ⚡ How to Run in VS Code

### 1. Install Dependencies
```bash
npm install
```

### 2. Populate Products & Demo Data
Ensure your MongoDB connection string is in `.env`, then run:
```bash
npm run seed
```

### 3. Start the Server
```bash
npm start
```

### 4. Open in Your Browser
Visit:
👉 **http://localhost:5000**
