const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');

// @route   POST /api/orders
// @desc    Place a new order (Simple checkout, no login required)
// @access  Public
router.post('/', async (req, res, next) => {
  try {
    const {
      orderItems,
      shippingAddress,
      customerName,
      paymentMethod,
      itemsPrice,
      shippingPrice,
      discount,
      totalPrice
    } = req.body;

    if (!orderItems || orderItems.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Your cart is empty. Please add items to order.'
      });
    }

    // Optional stock reduction
    for (const item of orderItems) {
      if (item.product) {
        const product = await Product.findById(item.product);
        if (product && product.stock >= item.qty) {
          product.stock -= item.qty;
          await product.save();
        }
      }
    }

    const order = new Order({
      customerName: customerName || (shippingAddress && shippingAddress.fullName) || 'Guest Customer',
      orderItems,
      shippingAddress: shippingAddress || {
        fullName: customerName || 'Customer',
        address: 'Direct Delivery',
        city: 'Local',
        phone: ''
      },
      paymentMethod: paymentMethod || 'Cash on Delivery (COD)',
      itemsPrice: Number(itemsPrice) || 0,
      shippingPrice: Number(shippingPrice) || 0,
      discount: Number(discount) || 0,
      totalPrice: Number(totalPrice) || 0,
      status: 'Processing'
    });

    const createdOrder = await order.save();

    res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order: createdOrder
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/orders
// @desc    Get all orders list (Simple tracking)
// @access  Public
router.get('/', async (req, res, next) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json({
      success: true,
      count: orders.length,
      orders
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/orders/:id
// @desc    Get single order details for invoice
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    res.json({
      success: true,
      order
    });
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/orders/:id/status
// @desc    Update order status from Admin panel
// @access  Public
router.put('/:id/status', async (req, res, next) => {
  try {
    const { status } = req.body;
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    order.status = status;
    const updatedOrder = await order.save();

    res.json({
      success: true,
      message: `Order status updated to ${status}`,
      order: updatedOrder
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
