const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// @route   GET /api/products/categories
// @desc    Get list of unique product categories
// @access  Public
router.get('/categories', async (req, res, next) => {
  try {
    const categories = await Product.distinct('category');
    res.json({
      success: true,
      categories
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/products
// @desc    Fetch all products with keyword search, category filter, and sorting
// @access  Public
router.get('/', async (req, res, next) => {
  try {
    const { keyword, category, sort } = req.query;
    const query = {};

    if (keyword && keyword.trim() !== '') {
      query.$or = [
        { name: { $regex: keyword.trim(), $options: 'i' } },
        { description: { $regex: keyword.trim(), $options: 'i' } }
      ];
    }

    if (category && category !== 'All' && category.trim() !== '') {
      query.category = { $regex: `^${category.trim()}$`, $options: 'i' };
    }

    let sortOption = { createdAt: -1 };
    if (sort === 'price-low') {
      sortOption = { price: 1 };
    } else if (sort === 'price-high') {
      sortOption = { price: -1 };
    } else if (sort === 'rating') {
      sortOption = { rating: -1 };
    }

    const products = await Product.find(query).sort(sortOption);

    res.json({
      success: true,
      count: products.length,
      products
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/products/:id
// @desc    Fetch single product by ID
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    res.json({
      success: true,
      product
    });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/products
// @desc    Create a new product (Simple Admin access)
// @access  Public
router.post('/', async (req, res, next) => {
  try {
    const { name, description, price, originalPrice, category, image, stock } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Product name and price are required'
      });
    }

    const product = new Product({
      name: name.trim(),
      description: description ? description.trim() : 'Quality product available at BudgetMart.',
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : Number(price) + 100,
      category: category ? category.trim() : 'General',
      image: image ? image.trim() : 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800&auto=format&fit=crop&q=80',
      stock: stock !== undefined ? Number(stock) : 20,
      rating: 4.5
    });

    const createdProduct = await product.save();
    res.status(201).json({
      success: true,
      message: 'Product added successfully!',
      product: createdProduct
    });
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/products/:id
// @desc    Update an existing product
// @access  Public
router.put('/:id', async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    const { name, description, price, originalPrice, category, image, stock } = req.body;

    if (name !== undefined) product.name = name.trim();
    if (description !== undefined) product.description = description.trim();
    if (price !== undefined) product.price = Number(price);
    if (originalPrice !== undefined) product.originalPrice = Number(originalPrice);
    if (category !== undefined) product.category = category.trim();
    if (image !== undefined) product.image = image.trim();
    if (stock !== undefined) product.stock = Number(stock);

    const updatedProduct = await product.save();
    res.json({
      success: true,
      message: 'Product updated successfully!',
      product: updatedProduct
    });
  } catch (error) {
    next(error);
  }
});

// @route   DELETE /api/products/:id
// @desc    Delete a product
// @access  Public
router.delete('/:id', async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    await Product.findByIdAndDelete(req.params.id);
    res.json({
      success: true,
      message: 'Product deleted successfully!'
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
