const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI);
    console.log(`✅ MongoDB Connected successfully: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    console.error('💡 Tip: Make sure your MongoDB service is running locally, or configure your MongoDB Atlas URI in the .env file.');
    // Do not crash the entire server process so developers can still see frontend routes or health checks
  }
};

module.exports = connectDB;
