const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product'
  },
  name: {
    type: String,
    required: true
  },
  qty: {
    type: Number,
    required: true,
    min: 1,
    default: 1
  },
  price: {
    type: Number,
    required: true,
    default: 0
  },
  image: {
    type: String,
    default: ''
  }
});

const shippingAddressSchema = new mongoose.Schema({
  fullName: {
    type: String,
    default: 'Customer'
  },
  phone: {
    type: String,
    default: ''
  },
  address: {
    type: String,
    default: 'Local Delivery'
  },
  city: {
    type: String,
    default: 'City'
  }
});

const orderSchema = new mongoose.Schema(
  {
    customerName: {
      type: String,
      default: 'Guest Customer'
    },
    orderItems: {
      type: [orderItemSchema],
      required: true
    },
    shippingAddress: {
      type: shippingAddressSchema,
      default: () => ({})
    },
    paymentMethod: {
      type: String,
      default: 'Cash on Delivery (COD)'
    },
    itemsPrice: {
      type: Number,
      default: 0
    },
    shippingPrice: {
      type: Number,
      default: 0
    },
    discount: {
      type: Number,
      default: 0
    },
    totalPrice: {
      type: Number,
      default: 0
    },
    status: {
      type: String,
      enum: ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'],
      default: 'Processing'
    }
  },
  {
    timestamps: true
  }
);

const Order = mongoose.model('Order', orderSchema);
module.exports = Order;
